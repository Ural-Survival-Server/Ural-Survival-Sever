# MCLangCN

适用于Minecraft基岩版的简体中文译名修正资源包。

An optimised Chinese Simplified translation for Minecraft Bedrock Edition.

按照[CC BY-NC-SA 4.0](https://creativecommons.org/licenses/by-nc-sa/4.0/deed.zh-Hans)协议发布

License Under [CC BY-NC-SA 4.0](https://creativecommons.org/licenses/by-nc-sa/4.0/deed)

Github: [https://github.com/ff98sha/mclangcn](https://github.com/ff98sha/mclangcn)

苦力怕BBS：[https://klpbbs.com/thread-137794-1-1.html](https://klpbbs.com/thread-137794-1-1.html)

MINEBBS：[https://www.minebbs.com/resources/8447/](https://www.minebbs.com/resources/8447/)
