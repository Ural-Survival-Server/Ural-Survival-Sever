THE TY-EL'S UI PACK
You can read more about Features, Credits, Changelogs, etc. in About Ty-el UI Screen in game, or on MCPEDL page.
https://mcpedl.com/the-ty-els-ui-pack/

-------- TERMS OF USE

YOU ARE FREE TO:
- Make contents about this pack as long as you credit me or the correct MCPEDL download link (or sources that I affiliated with)
- Modify my pack for personal uses, but you are not allowed to redistribute your modified versions of my pack
- Edit four modifiable texts in language file: "deathScreen.message", "deathScreen.subtitlemessage", "inBed.title" and "inBed.subtitle"
- Customize some variables in /ui/_global_variables.json file
- Add your own custom panorama, or create your own Ty-el Theme (instructions in /ui/_tyel_theme_template.json)

YOU ARE NOT ALLOWED TO:
- Use, or claim any of my code and use as your own, without permissions, please, please respect my hard works ;-;
- Re-upload this pack to different sites without proper permissions from me
- Make contents about this pack but without proper credits or provide different direct download links other than from MCPEDL (or from some other sources that I affiliated with), including link shorteners and direct download links

I know some of them are somehow very technical, but not that hard. If you don't understand them, don't worry, as long as you credit me when making contents about this pack, that's enough, I'm so bad ;-;

-------- CREDITS
- @NetherNinja - Drop Items buttons inspiration idea
- @ZouChenyunfei - Custom Pack Info in Pack Settings Screen
- @LukasPAH and wiki.bedrock.dev website - Item ID AUX and UI documentations
- @Chainsketch_ - Compatibility Mode for Ultimate Thumbnail Maker
- asakizuki (Discord) - Fixing Item ID calculator, methods to convert float numbers to strings
- Minecraft Vanilla UI and Sounds by ©Microsoft and ©Mojang Studios
- And other inspirations from contents by DualRed, RandomityGuy, CrisXolt, Tcbdxh and DrAv0011's Bedrock Tweaks

PACK TRANSLATORS
- Deutsch (Deutschland) - @Iam_best_dev (Twitter, minor fixes)
- Español (España) - @sebasxpert (Twitter), @TheCloverMC_01 (Twitter)
- Indonesia (Indonesia) - Sakha2017#5656 (Discord)
- Português - @will_ushuah (Twitter), @IjoaopedroAnd (Twitter)
- Türkçe (Türkiye) - Tentex#0807 (Discord)
- Русский (Россия) - @theqwermc (Twitter)
- Українська (Україна) - @tlgm2308 (Twitter, yep that's me) <3
- 日本語 (日本) - @nattsuiy (Twitter)
- 中文(中国) - @YangTuo_zi (Twitter), @student_2333 (Twitter), @mascot_fox8888 (Twitter), @_Pig_Peppa_ (Twitter)
- 中文(繁體) - @HonKit1103 (Twitter)

- @tlgm2308 - the bad guy ;-;